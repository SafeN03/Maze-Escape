#include "grid.h"
#include "maze.h"
#include <random>
#include <set>
#include <utility>
using namespace std;


const string kYourNetID = "snass"; //Stores my NetID

/* These are the paths out each maze*/
const string kPathOutOfRegularMaze ="ESSWNSENNESSSWENNNWESNWSSNNESE";
const string kPathOutOfTwistyMaze =
    "NNSENSW";

//Checks for specific conditions to gain freedom from the mazes
bool isPathToFreedom(MazeCell *start, const string &moves) {


    set<string> collectedItems;
    if (start->whatsHere == "Spellbook" || start->whatsHere == "Wand" ||
        start->whatsHere == "Potion") {
        collectedItems.insert(start->whatsHere);
    }

    MazeCell *current = start;

    for (char move : moves) {
        if (move == 'N') {
            if (current->north == nullptr) {
                return false;
            }
            current = current->north;
        } else if (move == 'E') {
            if (current->east == nullptr) {
                return false;
            }
            current = current->east;
        } else if (move == 'S') {
            if (current->south == nullptr) {
                return false;
            }
            current = current->south;
        } else if (move == 'W') {
            if (current->west == nullptr) {
                return false;
            }
            current = current->west;
        } else {
            return false;
        }
        if (current->whatsHere == "Spellbook" || current->whatsHere == "Wand" ||
            current->whatsHere == "Potion") {
            collectedItems.insert(current->whatsHere);
        }
    }
    return collectedItems.size() == 3;
}
