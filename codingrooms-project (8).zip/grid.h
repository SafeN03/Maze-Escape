/*------------------------------------------------
Safe Nassan
CS211
Project: Escape the Labyrinth - Grid Pointer Mazes
--------------------------------------------------*/


#pragma once
#include <algorithm>
#include <exception>
#include <iostream>
#include <stdexcept>
using namespace std;
template <typename T> 
class Grid {
  private:
    struct ROW {
        T *Cols;        // array of column elements
        size_t NumCols; // total # of columns (0..NumCols-1) 
        };
        ROW *Rows;      // array of ROWs
        size_t NumRows; // total # of rows (0..NumRows-1)
      public:
        //
        // default constructor:
        //
        // Called automatically by to construct a 4x4 Grid. // All elements
        // initialized to default value of T. //
        Grid() { //decides the amount of rows and columns
            Rows = new ROW[4]; // 4 rows
            NumRows = 4;
            // initialize each row to have 4 columns:
            for (size_t r = 0; r < NumRows; ++r) {
                Rows[r].Cols = new T[4];
                Rows[r].NumCols = 4;
                // initialize the elements to their default value:
                for (size_t c = 0; c < Rows[r].NumCols; ++c) {
                    Rows[r].Cols[c] = T(); // default value for type T: 
                    }
                }
            }
            Grid(size_t R, size_t C) {
                Rows = new ROW[R];
                NumRows = R;
                // Initialize each row with C columns
                for (size_t r = 0; r < NumRows; r++) {
                    Rows[r].Cols = new T[C];
                    Rows[r].NumCols = C;
                    
                }
            }
            virtual ~Grid() {
                for (size_t r = 0; r < NumRows; r++) {
                    delete[] Rows[r].Cols; // Frees each row's columns 
                    }
                    delete[] Rows;         // Frees the rows
                }
                // Copy constructor
                Grid(const Grid<T> &other) {
                    NumRows = other.NumRows; //copies number of rows
                    Rows = new ROW[NumRows]; 
                    for (size_t r = 0; r < NumRows; r++) {
                        Rows[r].NumCols = other.Rows[r].NumCols; //Copies the number of colums
                        Rows[r].Cols = new T[Rows[r].NumCols]; 
                        for (size_t c = 0; c < Rows[r].NumCols; c++) {
                            Rows[r].Cols[c] = other.Rows[r].Cols[c]; 
                        }
                    }
                }
                Grid &operator=(const Grid &other) {
                    if (this == &other)
                        return *this;
                    // Frees memory
                    for (size_t r = 0; r < NumRows; r++) {
                        delete[] Rows[r].Cols;
                    }
                    delete[] Rows;
                    // Updates new data
                    NumRows = other.NumRows;
                    Rows = new ROW[NumRows];
                    for (size_t r = 0; r < NumRows; r++) {
                        Rows[r].NumCols = other.Rows[r].NumCols;
                        Rows[r].Cols = new T[Rows[r].NumCols];
                        for (size_t c = 0; c < Rows[r].NumCols; c++) {
                            Rows[r].Cols[c] = other.Rows[r].Cols[c];
                        }
                    }
                    return *this;
                }
                size_t numrows() const { return NumRows; } //Gets number of rows
                size_t numcols(size_t r) const { //Gets the number of colums in specific rows
                    if (r >= NumRows)
                        throw out_of_range("Out of range");//Throws if the row element is out of range
                    return Rows[r].NumCols;
                }
                size_t size() const { //Gets the total number of elements
                    size_t totalSize = 0;
                    for (size_t r = 0; r < NumRows; r++) {
                        totalSize += Rows[r].NumCols; //Sums all th columns
                    }
                    return totalSize;
                }
                T &operator()(size_t r, size_t c) { //Checks the elemts in the rows and colums
                    if (r >= NumRows || c >= Rows[r].NumCols) {
                        throw out_of_range("Out of range"); //Throws if its out of range
                    }
                    return Rows[r].Cols[c];
                }
                void _output() { //Output the elements from the grid to the console
                    for (size_t r = 0; r < NumRows; r++) {
                        for (size_t c = 0; c < Rows[r].NumCols; c++) {
                            cout << Rows[r].Cols[c] << " ";
                        }
                        cout << endl;
                    }
                }
            };
